package Soal3_kasir;

public class Food extends Product implements Taxable {
    public Food(String name, double price) {
        super(name, price);
    }

    @Override
    public double calculateTax() {
        return price * 0.05;
    }

    @Override
    public double getTotalPrice() {
        return price + calculateTax();
    }
}
