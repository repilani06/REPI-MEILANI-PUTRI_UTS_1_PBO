package Soal3_kasir;

public interface Taxable {
    double calculateTax();
}
