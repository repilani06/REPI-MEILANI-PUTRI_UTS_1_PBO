package Soal3_kasir;

public class Beverage extends Product implements Taxable {

    public Beverage(String name, double price) {
        super(name, price);
    }

    @Override
    public double calculateTax() {
        return price * 0.10; // 10% pajak minuman
    }

    @Override
    public double getTotalPrice() {
        return price + calculateTax();
    }
}
