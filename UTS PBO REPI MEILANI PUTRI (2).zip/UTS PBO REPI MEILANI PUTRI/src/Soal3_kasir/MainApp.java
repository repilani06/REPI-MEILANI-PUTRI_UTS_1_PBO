package Soal3_kasir;

public class MainApp {
    public static void main(String[] args) {
        Product[] cart = new Product[] {
            new Food("Nasi Goreng", 20000),
            new Beverage("Teh Manis", 10000)
        };

        double total = 0;
        for (Product item : cart) {
            System.out.println(item.getName() + " - Rp" + item.getTotalPrice());
            total += item.getTotalPrice();
        }

        System.out.println("Total Bayar: Rp" + total);
    }
}
