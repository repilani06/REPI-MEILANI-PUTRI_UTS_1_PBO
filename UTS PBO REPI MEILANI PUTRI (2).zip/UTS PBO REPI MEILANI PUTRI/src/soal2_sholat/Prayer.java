package soal2_sholat;

public abstract class Prayer {
    protected String name;
    protected String time;

    public Prayer(String name, String time) {
        this.name = name;
        this.time = time;
    }

    public abstract void remind();
}