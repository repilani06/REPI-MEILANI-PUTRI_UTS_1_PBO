package soal2_sholat;

public class Maghrib extends Prayer implements AudioReminder {

    public Maghrib(String time) {
        super("Maghrib", time);
    }

    @Override
    public void remind() {
        System.out.println("Waktu " + name + " telah masuk pukul " + time + ". Segera sholat.");
    }

    @Override
    public void playAdzan() {
        System.out.println("Adzan Maghrib: 'Allahu Akbar Allahu Akbar...'");
    }
}
