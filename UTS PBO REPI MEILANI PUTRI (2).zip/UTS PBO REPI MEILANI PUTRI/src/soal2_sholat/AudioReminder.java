package soal2_sholat;

public interface AudioReminder {
    void playAdzan();
}