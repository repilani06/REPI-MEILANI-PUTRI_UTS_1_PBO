package soal2_sholat;

public class MainApp {
    public static void main(String[] args) {
        // Jika kelas Dhuhr dan Isha tidak dikenali, kemungkinan:
        // - File Dhuhr.java dan Isha.java tidak ada di folder sholat
        // - Package di file-file tersebut salah atau tidak dideklarasikan
        // - Kompilasi belum dijalankan untuk file-file ini
        Prayer fajr = new Fajr("04:50");
        Prayer dhuhr = new Dhuhr("12:22");   // ERROR: Dhuhr cannot be resolved to a type
        Prayer asr = new Asr("15:47");
        Prayer maghrib = new Maghrib("18:31");
        Prayer isha = new Isha("19:45");    // ERROR: Isha cannot be resolved to a type

        Prayer[] prayers = { fajr, dhuhr, asr, maghrib, isha };

        for (Prayer prayer : prayers) {
            prayer.remind();
            ((AudioReminder) prayer).playAdzan();
            System.out.println();
        }
    }
}
