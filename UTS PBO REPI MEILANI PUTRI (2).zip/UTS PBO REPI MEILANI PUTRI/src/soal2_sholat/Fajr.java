package soal2_sholat;

public class Fajr extends Prayer implements AudioReminder {

    public Fajr(String time) {
        super("Fajr", time);
    }

    @Override
    public void remind() {
        System.out.println("Waktu " + name + " tiba pada " + time + ". Waktunya sholat Subuh.");
    }

    @Override
    public void playAdzan() {
        System.out.println("Adzan Subuh: 'Ash-shalatu khairum minan naum...'");
    }
}
