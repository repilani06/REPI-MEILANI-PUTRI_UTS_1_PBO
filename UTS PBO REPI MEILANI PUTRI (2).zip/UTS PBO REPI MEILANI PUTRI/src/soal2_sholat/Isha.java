package soal2_sholat;

public class Isha extends Prayer implements AudioReminder {

    public Isha(String time) {
        super("Isha", time);
    }

    @Override
    public void remind() {
        System.out.println("Waktu " + name + " tiba pada " + time + ". Waktunya sholat Isya.");
    }

    @Override
    public void playAdzan() {
        System.out.println("Adzan Isya: 'Allahu Akbar Allahu Akbar...'");
    }
}
