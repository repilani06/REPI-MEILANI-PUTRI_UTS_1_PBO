package soal2_sholat;

public class Asr extends Prayer implements AudioReminder {

    public Asr(String time) {
        super("Asr", time);
    }

    @Override
    public void remind() {
        System.out.println("Sudah masuk waktu " + name + " pukul " + time + ". Jangan lupa sholat.");
    }

    @Override
    public void playAdzan() {
        System.out.println("Adzan Ashar: 'Allahu Akbar Allahu Akbar...'");
    }
}