package soal2_sholat;

public class Dhuhr extends Prayer implements AudioReminder {

    public Dhuhr(String time) {
        super("Dhuhr", time);
    }

    @Override
    public void remind() {
        System.out.println("Sudah masuk waktu " + name + " pukul " + time + ".");
    }

    @Override
    public void playAdzan() {
        System.out.println("Adzan Zuhur: 'Hayya 'ala-s-salah...'");
    }
}
