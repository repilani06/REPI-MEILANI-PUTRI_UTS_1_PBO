package Soal1;

// Car merupakan subclass dari Vehicle dan implementasi dari Electric
public class Car extends Vehicle implements Electric {

    public Car(String brand) {
        super(brand);
    }

    @Override
    public void startEngine() {
        System.out.println(brand + " mobil listrik dinyalakan otomatis.");
    }

    @Override
    public void chargeBattery() {
        System.out.println("Mengisi baterai mobil " + brand + "...");
    }
}
