package Soal1;

// Interface untuk kendaraan listrik
public interface Electric {
    void chargeBattery(); // Method untuk mengisi baterai
}
