package Soal1;

// Motorcycle hanya mewarisi Vehicle
public class Motorcycle extends Vehicle {

    public Motorcycle(String brand) {
        super(brand);
    }

    @Override
    public void startEngine() {
        System.out.println(brand + " motor dinyalakan secara manual.");
    }
}
