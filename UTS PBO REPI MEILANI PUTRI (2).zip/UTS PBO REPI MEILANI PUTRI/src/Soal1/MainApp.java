package Soal1;

public class MainApp {
    public static void main(String[] args) {
        // Polymorphism: referensi superclass digunakan untuk objek subclass
        Vehicle kendaraan1 = new Car("Tesla");
        Vehicle kendaraan2 = new Motorcycle("Yamaha");

        kendaraan1.startEngine();   // Output: Tesla mobil listrik dinyalakan otomatis.
        kendaraan2.startEngine();   // Output: Yamaha motor dinyalakan secara manual.

        // Pengecekan dan downcasting agar bisa panggil method chargeBattery()
        if (kendaraan1 instanceof Electric) {
            ((Electric) kendaraan1).chargeBattery(); // Output: Mengisi baterai mobil Tesla...
        }
    }
}
