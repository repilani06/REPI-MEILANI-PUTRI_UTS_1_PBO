package Soal1;

// Abstract class: superclass untuk semua kendaraan
public abstract class Vehicle {
    protected String brand;

    public Vehicle(String brand) {
        this.brand = brand;
    }

    // Method abstract wajib dioverride oleh subclass
    public abstract void startEngine();
}

